import Link from "next/link";
import "./globals.css";

export const metadata = {
  title: "South Regional Department Dashboard",
  description: "Atolls, islands and gensets at a glance",
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body>
        <header className="topbar">
          <Link href="/" className="brand">
            <span className="logo">
              <img src="/stelco-icon.png" alt="" width="55" height="24" />
              <span className="wordmark">STELCO</span>
            </span>
            <span>South Regional Department Dashboard</span>
          </Link>
        </header>
        <main className="page">{children}</main>
      </body>
    </html>
  );
}
